import './vaadin-featureflags.ts';

import './index';

import 'Frontend/generated/jar-resources/vaadin-dev-tools/vaadin-dev-tools.js';

import { applyTheme } from './theme.js';
applyTheme(document);
